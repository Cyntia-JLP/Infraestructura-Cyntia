# Cyntia — Ficheros de configuración

Este directorio contiene todos los ficheros de configuración modificados o creados durante el despliegue del proyecto Cyntia. Están organizados por máquina y ruta original en el sistema.

## Estructura

```
configs/
├── proxmox_host/                    # Ficheros del host Proxmox VE 8
│   ├── etc/
│   │   ├── network/
│   │   │   └── interfaces           # Configuración de red con VLANs 802.1Q
│   │   ├── nftables.conf            # Reglas de firewall y NAT
│   │   ├── sysctl.conf              # Parámetros del kernel (ip_forward, vm.max_map_count)
│   │   ├── hosts                    # Resolución de nombres del host
│   │   ├── fail2ban/
│   │   │   └── jail.local           # Configuración de fail2ban para SSH
│   │   └── pve/
│   │       └── lxc/
│   │           ├── 100.conf         # LXC lxc-pihole
│   │           ├── 101.conf         # LXC lxc-soc-core (Docker + Wazuh)
│   │           ├── 102.conf         # LXC lxc-web-cyntia (DMZ)
│   │           ├── 103.conf         # LXC lxc-honeypot
│   │           └── 104.conf         # LXC lxc-backup
│
├── lxc-pihole/                      # Ficheros del contenedor lxc-pihole (VMID 100)
│   └── etc/
│       └── pihole/
│           ├── custom.list          # Registros DNS del dominio cyntia.local
│           └── hosts                # Hosts internos del proyecto
│
└── lxc-soc-core/                    # Ficheros del contenedor lxc-soc-core (VMID 101)
    └── etc/
    │   └── docker/
    │       └── daemon.json          # Configuración del daemon de Docker
    └── opt/
        └── wazuh-docker/
            └── single-node/
                ├── docker-compose.yml                        # Stack Wazuh adaptado para LXC
                └── config/
                    └── wazuh_indexer/
                        └── internal_users.yml                # Usuarios de OpenSearch Security
```

## Notas importantes

### Sobre el docker-compose.yml
El fichero ha sido modificado respecto al oficial de Wazuh v4.9.2 en dos puntos:
1. **`security_opt: apparmor:unconfined`** añadido a los tres servicios — necesario porque Docker no puede acceder a los perfiles AppArmor del host desde dentro de un LXC no privilegiado.
2. **Bloques `ulimits` eliminados** — un LXC no privilegiado no puede modificar rlimits. El parámetro `vm.max_map_count=262144` en `sysctl.conf` del host cubre el requisito principal de OpenSearch.

### Sobre internal_users.yml
- El usuario `admin` tiene un hash inválido y `reserved: false` para deshabilitarlo.
- El usuario `cyntia` es el usuario operativo del SOC. Su hash corresponde a la contraseña del proyecto (ver documento de credenciales privado).
- `kibanaserver` se mantiene con sus valores por defecto porque es para comunicación interna entre servicios Docker.

### Sobre nftables.conf
- La tabla NAT usa `table ip nat` (no `table inet nat`) porque `dnat` solo está disponible en la familia `ip`.
- Las reglas de DNAT redirigen el tráfico de Tailscale al contenedor lxc-soc-core (192.168.20.3).

### Ficheros NO incluidos por seguridad
- Certificados SSL de Wazuh (`config/wazuh_indexer_ssl_certs/`) — se generan con `docker compose -f generate-indexer-certs.yml run --rm generator`
- Contraseñas en texto plano — ver documento de credenciales privado del equipo
- Claves privadas de Tailscale

## Cómo reproducir el entorno

Consultar las guías de instalación en el directorio `docs/`:
- `docs/guia_limpia_semana1.md` — Infraestructura base (Semana 1)
- `docs/guia_limpia_semana2.md` — SOC Core con Wazuh (Semana 2)

## Infraestructura de red

| Zona | Red | Gateway | Contenido |
|---|---|---|---|
| Host Proxmox | 192.168.3.100/24 | 192.168.3.1 | Hipervisor, nftables, Tailscale |
| DMZ | 192.168.50.0/24 | 192.168.50.1 | lxc-web-cyntia (portal web) |
| VLAN 10 | 192.168.10.0/24 | 192.168.10.1 | vm-windows-ad (Active Directory) |
| VLAN 20 | 192.168.20.0/24 | 192.168.20.1 | SOC Core, PiHole, Honeypot, Backup |

## IPs de los servicios

| Servicio | IP | Puerto |
|---|---|---|
| Proxmox WebUI | 192.168.3.100 / 100.92.243.96 | 8006 |
| PiHole DNS | 192.168.20.2 | 53 |
| Wazuh Dashboard | 192.168.20.3 / 100.92.243.96 | 443 |
| Wazuh API | 192.168.20.3 / 100.92.243.96 | 55000 |
| Wazuh Manager | 192.168.20.3 | 1514, 1515 |
| lxc-web-cyntia | 192.168.50.2 | 443 |
| lxc-honeypot | 192.168.20.4 | varios (señuelo) |
| lxc-backup | 192.168.20.5 | — |
